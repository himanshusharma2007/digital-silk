import React from 'react'

const Footer = () => {
  return (
    <div className='h-40 bg-purple-600 flex text-white justify-center items-center text-3xl'>
      This is Footer
    </div>
  )
}

export default Footer
